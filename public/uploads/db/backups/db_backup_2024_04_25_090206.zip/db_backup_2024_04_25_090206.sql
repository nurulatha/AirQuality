

-- ==================Table: histori_kualitas================== 

INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('1', '2024-04-24 18:47:02', 'AMAN', '3', '1', '100');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('2', '2024-04-24 18:47:02', 'AMAN', '1', '1', '32.47');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('3', '2024-04-24 18:47:02', 'AMAN', '2', '2', '39.49');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('4', '2024-04-24 18:47:02', 'AMAN', '3', '3', '93.32');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('5', '2024-04-24 18:47:02', 'AMAN', '4', '4', '184.61');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('6', '2024-04-24 18:47:02', 'AMAN', '5', '1', '40.02');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('7', '2024-04-24 18:47:02', 'AMAN', '6', '2', '82.14');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('8', '2024-04-24 18:47:02', 'AMAN', '1', '1', '14');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('9', '2024-04-24 18:47:02', 'AMAN', '2', '1', '58');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('10', '2024-04-24 18:47:02', 'BAHAYA', '3', '1', '303');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('11', '2024-04-24 18:47:02', 'BAHAYA', '4', '1', '119');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('12', '2024-04-24 18:47:02', 'AMAN', '5', '1', '42');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('13', '2024-04-24 18:47:02', 'BAHAYA', '6', '1', '126');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('14', '2024-04-24 18:47:02', 'AMAN', '1', '2', '17');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('15', '2024-04-24 18:47:02', 'AMAN', '2', '2', '39');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('16', '2024-04-24 18:47:02', 'BAHAYA', '3', '2', '139');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('17', '2024-04-24 18:47:02', 'BAHAYA', '4', '2', '141');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('18', '2024-04-24 18:47:02', 'AMAN', '5', '2', '16');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('19', '2024-04-24 18:47:02', 'BAHAYA', '6', '2', '172');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('20', '2024-04-24 18:47:02', 'AMAN', '1', '3', '13');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('21', '2024-04-24 18:47:02', 'AMAN', '2', '3', '35');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('22', '2024-04-24 18:47:02', 'BAHAYA', '3', '3', '123');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('23', '2024-04-24 18:47:02', 'BAHAYA', '4', '3', '159');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('24', '2024-04-24 18:47:02', 'AMAN', '5', '3', '47');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('25', '2024-04-24 18:47:02', 'BAHAYA', '6', '3', '104');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('26', '2024-04-24 18:47:02', 'AMAN', '1', '4', '11');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('27', '2024-04-24 18:47:02', 'AMAN', '2', '4', '41');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('28', '2024-04-24 18:47:02', 'BAHAYA', '3', '4', '231');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('29', '2024-04-24 18:47:02', 'BAHAYA', '4', '4', '182');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('30', '2024-04-24 18:47:02', 'AMAN', '5', '4', '33');
INSERT INTO `histori_kualitas` (`id`, `waktu`, `keterangan`, `id_parameter`, `id_alat`, `nilai_parameter`) VALUES ('31', '2024-04-24 18:47:02', 'BAHAYA', '6', '4', '93');


-- ==================Table: histori_sampahs================== 

INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('1', '3', '2024-04-24 17:32:46', '100', 'AMAN', '1');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('2', '2', '2024-04-24 17:33:04', '100', 'AMAN', '1');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('3', '1', '2024-04-24 17:33:33', '110', 'AMAN', '2');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('4', '4', '2024-04-24 17:33:33', '500', 'WASPADA', '3');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('7', '6', '2024-04-24 17:42:29', '600', 'BAHAYA', '4');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('8', '3', '2024-04-24 17:43:37', '100', 'AMAN', '1');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('9', '3', '2024-04-24 22:49:46', '100', 'WASPADA', '3');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('10', '3', '2024-04-24 17:50:19', '100', 'AMAN', '1');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('11', '2', '2024-04-24 17:43:37', '100', 'AMAN', '1');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('12', '4', '2024-04-24 17:43:37', '100', 'WASPADA', '1');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('13', '6', '2024-04-24 17:43:37', '100', 'BAHAYA', '1');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('14', '2', '2024-04-24 17:43:37', '100', 'AMAN', '1');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('15', '3', '2024-04-24 17:43:37', '100', 'AMAN', '1');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('16', '1', '2024-04-24 17:43:37', '100', 'AMAN', '2');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('17', '5', '2024-04-24 17:43:37', '100', 'WASPADA', '2');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('18', '7', '2024-04-24 17:43:37', '100', 'BAHAYA', '2');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('19', '2', '2024-04-24 17:43:37', '100', 'AMAN', '2');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('20', '4', '2024-04-24 17:43:37', '100', 'WASPADA', '2');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('21', '3', '2024-04-24 17:43:37', '100', 'AMAN', '3');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('22', '6', '2024-04-24 17:43:37', '100', 'WASPADA', '3');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('23', '8', '2024-04-24 17:43:37', '100', 'BAHAYA', '3');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('24', '4', '2024-04-24 17:43:37', '100', 'WASPADA', '3');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('25', '2', '2024-04-24 17:43:37', '100', 'AMAN', '3');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('26', '4', '2024-04-24 17:43:37', '100', 'WASPADA', '4');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('27', '7', '2024-04-24 17:43:37', '100', 'BAHAYA', '4');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('28', '9', '2024-04-24 17:43:37', '100', 'BAHAYA', '4');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('29', '3', '2024-04-24 17:43:37', '100', 'AMAN', '4');
INSERT INTO `histori_sampahs` (`id`, `ketinggian_sampah`, `waktu`, `volume`, `keterangan`, `id_alat`) VALUES ('30', '5', '2024-04-24 17:43:37', '100', 'WASPADA', '4');


-- ==================Table: kawasan================== 

INSERT INTO `kawasan` (`id_kawasan`, `luas_kawasan`, `id_tpa`) VALUES ('1', '50', '1');
INSERT INTO `kawasan` (`id_kawasan`, `luas_kawasan`, `id_tpa`) VALUES ('2', '50', '1');
INSERT INTO `kawasan` (`id_kawasan`, `luas_kawasan`, `id_tpa`) VALUES ('3', '50', '1');
INSERT INTO `kawasan` (`id_kawasan`, `luas_kawasan`, `id_tpa`) VALUES ('4', '50', '1');


-- ==================Table: lokasi_tpa================== 

INSERT INTO `lokasi_tpa` (`id_tpa`, `luas_tpa`, `lokasi_tpa`) VALUES ('0', '10', 'lokasi A');
INSERT INTO `lokasi_tpa` (`id_tpa`, `luas_tpa`, `lokasi_tpa`) VALUES ('1', '200', 'AAAAAA');
INSERT INTO `lokasi_tpa` (`id_tpa`, `luas_tpa`, `lokasi_tpa`) VALUES ('2', '200', 'BBBBBBBB');


-- ==================Table: menus================== 

INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('1', 'Menu Manajemen', '#', '', '', '0', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('2', 'Dashboard', 'home', 'fas fa-home', '', '1', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('3', 'Manajemen Pengguna', '#', 'fas fa-users-cog', '', '1', '2');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('4', 'Kelola Pengguna', 'manage-user', '', '', '3', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('5', 'Kelola Role', 'manage-role', '', '', '3', '2');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('6', 'Kelola Menu', 'manage-menu', '', '', '3', '3');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('7', 'Backup Server', '#', '', '', '0', '2');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('8', 'Backup Database', 'dbbackup', 'fas fa-database', '', '7', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('9', 'Pooling', '#', 'fa fa-poll', '', '1', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('10', 'Data Sampah', 'sampah', 'far fa-circle', '', '9', '1');
INSERT INTO `menus` (`id`, `nama_menu`, `url`, `icon`, `id_html`, `parent_id`, `urutan`) VALUES ('11', 'Data Kualitas Udara', 'udara', 'far fa-circle', '', '9', '1');


-- ==================Table: migrations================== 

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('1', '2014_10_12_000000_create_users_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('2', '2014_10_12_100000_create_password_resets_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('3', '2019_08_19_000000_create_failed_jobs_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('4', '2019_12_14_000001_create_personal_access_tokens_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('5', '2024_01_01_234158_create_menus_table', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('6', '2024_02_02_053619_create_permission_tables', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('7', '2024_02_03_232722_create_role_has_menus_tables', '1');
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES ('8', '2024_02_03_235312_add_menu_id_on_permission', '1');


-- ==================Table: model_has_roles================== 

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES ('1', 'App\\Models\\User', '1');


-- ==================Table: parameter_kualitas_udara================== 

INSERT INTO `parameter_kualitas_udara` (`id`, `nama_parameter`, `batas_parameter_atas`, `batas_parameter_bawahan`, `satuan`) VALUES ('1', 'PM2.5', '35', '15', '');
INSERT INTO `parameter_kualitas_udara` (`id`, `nama_parameter`, `batas_parameter_atas`, `batas_parameter_bawahan`, `satuan`) VALUES ('2', 'PM10', '60', '30', '');
INSERT INTO `parameter_kualitas_udara` (`id`, `nama_parameter`, `batas_parameter_atas`, `batas_parameter_bawahan`, `satuan`) VALUES ('3', 'SO2', '350', '50', 'ug/m3');
INSERT INTO `parameter_kualitas_udara` (`id`, `nama_parameter`, `batas_parameter_atas`, `batas_parameter_bawahan`, `satuan`) VALUES ('4', 'NO2', '200', '50', 'ug/m3');
INSERT INTO `parameter_kualitas_udara` (`id`, `nama_parameter`, `batas_parameter_atas`, `batas_parameter_bawahan`, `satuan`) VALUES ('5', 'CO', '50', '10', 'ug/m3');
INSERT INTO `parameter_kualitas_udara` (`id`, `nama_parameter`, `batas_parameter_atas`, `batas_parameter_bawahan`, `satuan`) VALUES ('6', 'O3', '180', '60', 'ug/m3');


-- ==================Table: permissions================== 

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('1', 'create_user', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '4');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('2', 'read_user', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '4');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('3', 'update_user', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '4');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('4', 'delete_user', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '4');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('5', 'create_role', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '5');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('6', 'read_role', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '5');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('7', 'update_role', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '5');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('8', 'delete_role', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '5');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('9', 'create_menu', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '6');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('10', 'read_menu', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '6');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('11', 'update_menu', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '6');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('12', 'delete_menu', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '6');
INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`, `menu_id`) VALUES ('13', 'backup_database', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11', '8');


-- ==================Table: referensi_alat================== 

INSERT INTO `referensi_alat` (`id_alat`, `nama_alat`, `kode_alat`, `id_kawasan`) VALUES ('1', 'ALAT1', '001', '1');
INSERT INTO `referensi_alat` (`id_alat`, `nama_alat`, `kode_alat`, `id_kawasan`) VALUES ('2', 'ALAT2', '002', '2');
INSERT INTO `referensi_alat` (`id_alat`, `nama_alat`, `kode_alat`, `id_kawasan`) VALUES ('3', 'ALAT3', '003', '3');
INSERT INTO `referensi_alat` (`id_alat`, `nama_alat`, `kode_alat`, `id_kawasan`) VALUES ('4', 'ALAT4', '004', '4');


-- ==================Table: roles================== 

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES ('1', 'superadmin', 'web', '2024-04-04 05:11:11', '2024-04-04 05:11:11');


-- ==================Table: role_has_menus================== 

INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('1', '1', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('2', '2', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('3', '3', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('4', '4', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('5', '5', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('6', '6', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('7', '7', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('8', '8', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('9', '1', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('10', '2', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('11', '3', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('12', '4', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('13', '5', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('14', '6', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('15', '9', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('16', '10', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('17', '11', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('18', '7', '1');
INSERT INTO `role_has_menus` (`id`, `menu_id`, `role_id`) VALUES ('19', '8', '1');


-- ==================Table: role_has_permissions================== 

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('1', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('2', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('3', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('4', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('5', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('6', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('7', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('8', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('9', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('10', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('11', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('12', '1');
INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES ('13', '1');


-- ==================Table: users================== 

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES ('1', 'Super Admin', 'superadmin@gmail.com', '2024-04-04 05:11:11', '$2y$10$YKO/suSeG.y2NI4N6ycMMOl7kN1HLWBaleL3aD8ZhFwB.fQoUi9Xu', '7UEG05IW4UkILiriKElrxvgqs5EfYKX3Z2RQHKBEpzHfi5lJPmHSl7G8gZ1M', '2024-04-04 05:11:11', '2024-04-04 05:11:11');
